#!/usr/bin/env bash
# =============================================================================
# MySQL Security Audit  -  main driver
# =============================================================================
#
# Reads connection details from ./config.env, opens an SSH tunnel if
# configured, runs the CIS-aligned checks in lib/checks.sh, and writes a
# report to out/mysql_audit_<timestamp>/.
#
# Usage:
#   bash audit_mysql.sh
#
# =============================================================================
IFS=$'\n\t'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

if [ ! -f config.env ]; then
    echo "ERROR: config.env not found next to audit_mysql.sh" >&2
    exit 1
fi
# shellcheck disable=SC1091
source config.env

# Timestamped output dir
STAMP=$(date -u '+%Y%m%d_%H%M%S')
OUT_DIR="$SCRIPT_DIR/out/mysql_audit_${STAMP}"
REPORT_TXT="$OUT_DIR/report.txt"
REPORT_CSV="$OUT_DIR/report.csv"
RAW_DIR="$OUT_DIR/raw"
mkdir -p "$RAW_DIR"

# shellcheck disable=SC1091
source "$SCRIPT_DIR/lib/output.sh"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/lib/connect.sh"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/lib/checks.sh"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/lib/os_checks.sh"

# Always tear down the tunnel + write final summary, even on error / interrupt.
cleanup() {
    close_tunnel || true
    finalize_report
    echo
    echo "Report written to: $OUT_DIR"
}
trap cleanup EXIT INT TERM

open_tunnel_if_needed

init_report

echo -n ' Testing MySQL connectivity ... '
if VERSION_OUT=$(test_connection); then
    printf '%bconnected%b (server: %s)\n' "$C_PASS" "$C_NC" "$VERSION_OUT"
else
    printf '%bfailed%b\n%s\n' "$C_FAIL" "$C_NC" "$VERSION_OUT"
    echo 'Aborting audit. Fix credentials or tunnel first.' >&2
    exit 2
fi

# Probe whether the audit user can read mysql.user; drives Section 5 + parts
# of Section 7/8. Announce the result so the auditor knows what to expect.
probe_user_table_access
if [ "$USER_TABLE_READABLE" = "1" ]; then
    printf ' %baudit user can read mysql.user%b - full privilege coverage.\n' "$C_PASS" "$C_NC"
else
    printf ' %baudit user cannot read mysql.user%b - Section 5 + some Section 7/8 items skipped as Info.\n' "$C_WARN" "$C_NC"
    printf '   Grant SELECT ON mysql.user (or run as an admin user) to enable them.\n'
fi

run_all_checks
run_all_os_checks
