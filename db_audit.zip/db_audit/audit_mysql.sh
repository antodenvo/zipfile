#!/usr/bin/env bash
# =============================================================================
# MySQL Security Audit  -  main driver
# =============================================================================
#
# Reads connection details from ./config.env, opens an SSH tunnel if
# configured, runs the CIS-aligned checks in lib/checks.sh, and writes a
# report to out/mysql_audit_<timestamp>/.
#
# Usage:
#   bash audit_mysql.sh
#
# =============================================================================
IFS=$'\n\t'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

if [ ! -f config.env ]; then
    echo "ERROR: config.env not found next to audit_mysql.sh" >&2
    exit 1
fi
# shellcheck disable=SC1091
source config.env

# Timestamped output dir
STAMP=$(date -u '+%Y%m%d_%H%M%S')
OUT_DIR="$SCRIPT_DIR/out/mysql_audit_${STAMP}"
REPORT_TXT="$OUT_DIR/report.txt"
REPORT_CSV="$OUT_DIR/report.csv"
RAW_DIR="$OUT_DIR/raw"
mkdir -p "$RAW_DIR"

# shellcheck disable=SC1091
source "$SCRIPT_DIR/lib/output.sh"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/lib/connect.sh"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/lib/checks.sh"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/lib/os_checks.sh"

# Always tear down the tunnel + write final summary, even on error / interrupt.
cleanup() {
    close_tunnel || true
    finalize_report
    echo
    echo "Report written to: $OUT_DIR"
}
trap cleanup EXIT INT TERM

open_tunnel_if_needed

init_report

echo -n ' Testing MySQL connectivity ... '
if VERSION_OUT=$(test_connection); then
    printf '%bconnected%b (server: %s)\n' "$C_PASS" "$C_NC" "$VERSION_OUT"
else
    printf '%bfailed%b\n%s\n' "$C_FAIL" "$C_NC" "$VERSION_OUT"
    echo 'Aborting audit. Fix credentials or tunnel first.' >&2
    exit 2
fi

run_all_checks
run_all_os_checks
