-- =============================================================================
-- Intentional-insecure seed data for the audit testbed.
--   * anonymous account (@localhost)                  -> fails 7.1
--   * empty-password account                          -> fails 7.2
--   * app user with FILE/PROCESS/SUPER/GRANT/etc      -> fails 5.1..5.6
--   * global DML/DDL (*.* SELECT/INSERT/UPDATE/DELETE) -> fails 5.8
--   * remote root                                     -> fails 7.7
--   * 'test' database recreated                       -> fails 7.8
-- The rest (log_raw, secure_file_priv, TLS)  come from MySQL 8's own defaults
-- which we leave untouched, so those checks show real observed values.
-- =============================================================================

-- Anonymous account (Fail 7.1)
CREATE USER IF NOT EXISTS ''@'localhost';

-- Empty-password account (Fail 7.2)
CREATE USER IF NOT EXISTS 'nopwd'@'%' IDENTIFIED BY '';

-- Over-privileged application user (Fail 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 5.8)
CREATE USER IF NOT EXISTS 'app_bad'@'%' IDENTIFIED BY 'AppBadP@ss1';
GRANT FILE, PROCESS, SUPER, SHUTDOWN, CREATE USER, RELOAD ON *.* TO 'app_bad'@'%';
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, DROP ON *.* TO 'app_bad'@'%' WITH GRANT OPTION;

-- Remote root (Fail 7.7)
CREATE USER IF NOT EXISTS 'root'@'%' IDENTIFIED BY 'RemoteRootPw@1';
GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' WITH GRANT OPTION;

-- 'test' database (Fail 7.8)
CREATE DATABASE IF NOT EXISTS test;

FLUSH PRIVILEGES;

-- A well-behaved app user (should not raise any Fail)
CREATE USER IF NOT EXISTS 'app_ok'@'%' IDENTIFIED BY 'AppOkP@ss1';
CREATE DATABASE IF NOT EXISTS app_ok_db;
GRANT SELECT, INSERT, UPDATE, DELETE ON app_ok_db.* TO 'app_ok'@'%';
ALTER USER 'app_ok'@'%' REQUIRE SSL;
