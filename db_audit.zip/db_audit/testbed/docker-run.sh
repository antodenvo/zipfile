#!/usr/bin/env bash
# =============================================================================
# testbed/docker-run.sh
# Deploys a MySQL 8.0 container on the remote host (SSH_HOST from config.env)
# so we can exercise audit_mysql.sh against a real DB without touching prod.
#
# Usage:
#   bash testbed/docker-run.sh up      # start container + seed intentional issues
#   bash testbed/docker-run.sh down    # stop and remove
#   bash testbed/docker-run.sh logs    # tail container logs
#   bash testbed/docker-run.sh status  # is the container running
# =============================================================================
set -u

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

# shellcheck disable=SC1091
source "$ROOT_DIR/config.env"
# shellcheck disable=SC1091
source "$ROOT_DIR/lib/connect.sh"   # for ssh_x / ssh_x_tunnel

: "${SSH_HOST:?SSH_HOST must be set in config.env to deploy the test container}"

CONTAINER=mysql_audit_test
IMAGE=mysql:8.0
REMOTE_PORT=${SSH_TARGET_PORT:-3306}
ROOT_PW=${MYSQL_PASSWORD:-testroot}

case "${1:-up}" in
    up)
        echo " Deploying $IMAGE on $SSH_HOST as $CONTAINER (port $REMOTE_PORT)"
        ssh_x bash -s <<REMOTE
set -e
docker pull $IMAGE >/dev/null
docker rm -f $CONTAINER 2>/dev/null || true
docker run -d --name $CONTAINER \\
    -e MYSQL_ROOT_PASSWORD='$ROOT_PW' \\
    -p 127.0.0.1:$REMOTE_PORT:3306 \\
    $IMAGE >/dev/null

# Wait for MySQL to be ready
printf ' Waiting for MySQL to come up'
for i in \$(seq 1 60); do
    if docker exec $CONTAINER mysqladmin -uroot -p'$ROOT_PW' ping >/dev/null 2>&1; then
        echo ' ready'
        break
    fi
    printf '.'
    sleep 2
done
REMOTE

        if [ -f "$SCRIPT_DIR/seed.sql" ]; then
            echo ' Loading seed.sql (creates insecure users/DB for testing)'
            ssh_x "docker exec -i $CONTAINER mysql -uroot -p'$ROOT_PW'" \
                < "$SCRIPT_DIR/seed.sql" 2>&1 | grep -viE '^warning|using a password' || true
        fi

        echo
        echo " Container running on $SSH_HOST at 127.0.0.1:$REMOTE_PORT"
        echo " Now: bash audit_mysql.sh"
        ;;

    down)
        echo " Stopping $CONTAINER on $SSH_HOST"
        ssh_x "docker rm -f $CONTAINER 2>/dev/null || true"
        echo ' done'
        ;;

    logs)
        ssh_x "docker logs --tail 200 -f $CONTAINER"
        ;;

    status)
        ssh_x "docker ps --filter name=$CONTAINER --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'"
        ;;

    *)
        echo "Usage: $0 {up|down|logs|status}" >&2
        exit 1
        ;;
esac
