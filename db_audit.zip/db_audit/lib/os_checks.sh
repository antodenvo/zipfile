#!/usr/bin/env bash
# =============================================================================
# lib/os_checks.sh
# OS-level CIS MySQL controls that need shell access to the DB host.
# Runs commands via sh_wrap() (docker exec / ssh / local depending on config).
#
# Each check is prefixed 'os_' and gets a section number (1.x = files, 2.x =
# process / user hygiene, 3.x = encryption at rest, 10.x = backup).
# =============================================================================

# ---------- helper: get an octal mode + owner + group for a path -----------
# Emits "MODE OWNER GROUP" on one line, or "MISSING" if the path doesn't exist.
stat_line() {
    local path="$1"
    # Try GNU stat first (Linux); fall back to BSD stat if that fails.
    sh_wrap "if [ -e '$path' ]; then \
                stat -c '%a %U %G' '$path' 2>/dev/null || \
                stat -f '%Lp %Su %Sg' '$path' 2>/dev/null; \
             else \
                printf 'MISSING\n'; \
             fi" | tr -d '\r' | head -1
}

# ---------- helper: pull a system variable to know the actual path ----------
# (already have svar in checks.sh; alias here for readability)
os_svar() { svar "$1"; }

# =============================================================================
# 1. FILE PERMISSIONS ON DATA / LOG / CONFIG FILES
# =============================================================================
run_section_os_files() {
    section_hdr '1. OS-level Files & Permissions'

    local path line mode owner group

    # 1.1 datadir owned by mysql:mysql, 700 (or 750)
    path=$(os_svar 'datadir')
    line=$(stat_line "${path%/}")
    save_raw '1.1_datadir_perms' "path=$path stat=$line"
    if [ "$line" = "MISSING" ] || [ -z "$line" ]; then
        check_result '1.1' 'OS-Files' 'datadir accessible' 'Medium' 'Info' \
            "Could not stat $path (no shell access to DB host?)" \
            'Ensure the audit user can reach the DB host filesystem to verify permissions.'
    else
        mode=$(echo "$line" | awk '{print $1}')
        owner=$(echo "$line" | awk '{print $2}')
        if [ "${mode:0:1}" = "7" ] && [ "$owner" = "mysql" ]; then
            check_result '1.1' 'OS-Files' 'datadir permissions (700 mysql)' 'High' 'Pass' \
                "$path mode=$mode owner=$owner" '-'
        else
            check_result '1.1' 'OS-Files' 'datadir permissions (700 mysql)' 'High' 'Fail' \
                "$path mode=$mode owner=$owner (expected 700 owned by mysql)" \
                "chown -R mysql:mysql $path && chmod 700 $path"
        fi
    fi

    # 1.2 log_error file permissions (only if it's a real file path)
    path=$(os_svar 'log_error')
    if [ -n "$path" ] && [ "$path" != "stderr" ] && [ "${path:0:1}" = "/" ]; then
        line=$(stat_line "$path")
        save_raw '1.2_log_error_perms' "path=$path stat=$line"
        if [ "$line" = "MISSING" ]; then
            check_result '1.2' 'OS-Files' 'log_error permissions' 'Medium' 'Info' \
                "log_error path $path not present yet" '-'
        else
            mode=$(echo "$line" | awk '{print $1}')
            owner=$(echo "$line" | awk '{print $2}')
            if [ "$owner" = "mysql" ] && [ "${mode:2:1}" = "0" ] || [ "${mode:2:1}" = "" ]; then
                check_result '1.2' 'OS-Files' 'log_error permissions' 'Medium' 'Pass' \
                    "$path mode=$mode owner=$owner" '-'
            else
                check_result '1.2' 'OS-Files' 'log_error permissions' 'Medium' 'Warn' \
                    "$path mode=$mode owner=$owner (world bit set?)" \
                    "chown mysql:mysql $path && chmod 640 $path"
            fi
        fi
    else
        check_result '1.2' 'OS-Files' 'log_error permissions' 'Medium' 'Info' \
            "log_error=$path (stderr / non-file - see check 6.1)" '-'
    fi

    # 1.3 slow_query_log_file permissions (only if slow_query_log is ON)
    local slow_on
    slow_on=$(os_svar 'slow_query_log')
    path=$(os_svar 'slow_query_log_file')
    if [ "$slow_on" = "ON" ] && [ -n "$path" ]; then
        line=$(stat_line "$path")
        save_raw '1.3_slow_query_log_perms' "path=$path stat=$line"
        if [ "$line" = "MISSING" ]; then
            check_result '1.3' 'OS-Files' 'slow_query_log file permissions' 'Low' 'Info' \
                "slow_query_log path $path not present yet" '-'
        else
            mode=$(echo "$line" | awk '{print $1}')
            if [ "${mode:2:1}" = "0" ] || [ -z "${mode:2:1}" ]; then
                check_result '1.3' 'OS-Files' 'slow_query_log file permissions' 'Low' 'Pass' \
                    "$path mode=$mode" '-'
            else
                check_result '1.3' 'OS-Files' 'slow_query_log file permissions' 'Low' 'Warn' \
                    "$path mode=$mode (world-accessible)" \
                    "chown mysql:mysql $path && chmod 640 $path"
            fi
        fi
    else
        check_result '1.3' 'OS-Files' 'slow_query_log file permissions' 'Low' 'Info' \
            "slow_query_log=$slow_on (not enabled)" '-'
    fi

    # 1.4 plugin_dir 755 owned by root/mysql
    path=$(os_svar 'plugin_dir')
    line=$(stat_line "${path%/}")
    save_raw '1.4_plugin_dir_perms' "path=$path stat=$line"
    if [ "$line" = "MISSING" ] || [ -z "$line" ]; then
        check_result '1.4' 'OS-Files' 'plugin_dir permissions' 'Medium' 'Info' \
            "Could not stat $path" '-'
    else
        mode=$(echo "$line" | awk '{print $1}')
        owner=$(echo "$line" | awk '{print $2}')
        # Expect 0755 owned by mysql or root; anything world-writable is a Fail
        if [ "${mode:2:1}" != "2" ] && [ "${mode:2:1}" != "3" ] && [ "${mode:2:1}" != "6" ] && [ "${mode:2:1}" != "7" ]; then
            check_result '1.4' 'OS-Files' 'plugin_dir permissions' 'Medium' 'Pass' \
                "$path mode=$mode owner=$owner" '-'
        else
            check_result '1.4' 'OS-Files' 'plugin_dir permissions' 'Medium' 'Fail' \
                "$path mode=$mode owner=$owner (world-writable)" \
                "chown -R mysql:mysql $path && chmod 755 $path"
        fi
    fi

    # 1.5 my.cnf not world-writable (check common paths)
    save_raw '1.5_mycnf_check' "$(sh_wrap 'ls -l /etc/my.cnf /etc/mysql/my.cnf /etc/mysql/mysql.conf.d/*.cnf 2>/dev/null')"
    local bad_cnf
    bad_cnf=$(sh_wrap 'for f in /etc/my.cnf /etc/mysql/my.cnf /etc/mysql/mysql.conf.d/*.cnf ~/.my.cnf; do [ -f "$f" ] || continue; mode=$(stat -c "%a" "$f" 2>/dev/null); world=$(printf "%s" "$mode" | tail -c 1); if [ "$world" = "2" ] || [ "$world" = "3" ] || [ "$world" = "6" ] || [ "$world" = "7" ]; then echo "$f mode=$mode"; fi; done')
    bad_cnf=$(echo "$bad_cnf" | tr -d '\r' | grep -v '^$')
    if [ -z "$bad_cnf" ]; then
        check_result '1.5' 'OS-Files' 'my.cnf not world-writable' 'High' 'Pass' \
            'No world-writable my.cnf found' '-'
    else
        check_result '1.5' 'OS-Files' 'my.cnf not world-writable' 'High' 'Fail' \
            "World-writable config file(s): $bad_cnf" \
            'chmod 640 the listed config files and set ownership to root:mysql.'
    fi
}

# =============================================================================
# 2. PROCESS / USER HYGIENE
# =============================================================================
run_section_os_process() {
    section_hdr '2. Process & User Hygiene'

    # 2.1 mysqld running as non-root user
    local out
    out=$(sh_wrap "ps -eo user,comm 2>/dev/null | awk '\$2==\"mysqld\" || \$2==\"mysqld_safe\" {print \$1}' | sort -u | head -3")
    save_raw '2.1_mysqld_user' "$out"
    if [ -z "$out" ]; then
        check_result '2.1' 'Process' 'mysqld not running as root' 'Info' 'Info' \
            'Could not identify mysqld process (no shell access?)' '-'
    elif echo "$out" | grep -q '^root$'; then
        check_result '2.1' 'Process' 'mysqld not running as root' 'High' 'Fail' \
            "mysqld running as: $out" \
            'Configure my.cnf [mysqld] user=mysql and restart. Never run mysqld as root.'
    else
        check_result '2.1' 'Process' 'mysqld not running as root' 'High' 'Pass' \
            "mysqld running as: $out" '-'
    fi

    # 2.2 MYSQL_PWD environment variable not exposed in running processes
    out=$(sh_wrap "grep -laE 'MYSQL_PWD=' /proc/*/environ 2>/dev/null | head -5")
    save_raw '2.2_mysql_pwd_env' "$out"
    if [ -z "$out" ]; then
        check_result '2.2' 'Process' 'MYSQL_PWD env var not used' 'Medium' 'Pass' \
            'No running process exposes MYSQL_PWD' '-'
    else
        check_result '2.2' 'Process' 'MYSQL_PWD env var not used' 'Medium' 'Fail' \
            "MYSQL_PWD found in: $out" \
            'Use --login-path or a protected .my.cnf instead of MYSQL_PWD.'
    fi

    # 2.3 mysql_history redirected / absent
    out=$(sh_wrap 'for h in /home/*/.mysql_history /root/.mysql_history; do [ -f "$h" ] || continue; ls -l "$h" 2>/dev/null; done')
    save_raw '2.3_mysql_history' "$out"
    if [ -z "$out" ]; then
        check_result '2.3' 'Process' '.mysql_history redirected / absent' 'Low' 'Pass' \
            'No .mysql_history file found in typical locations' '-'
    else
        # Check if symlinked to /dev/null
        if echo "$out" | grep -q '/dev/null'; then
            check_result '2.3' 'Process' '.mysql_history redirected / absent' 'Low' 'Pass' \
                '.mysql_history symlinked to /dev/null' '-'
        else
            check_result '2.3' 'Process' '.mysql_history redirected / absent' 'Low' 'Warn' \
                ".mysql_history file(s) exist: $out" \
                'Symlink .mysql_history to /dev/null for accounts that use the mysql CLI.'
        fi
    fi

    # 2.4 no .my.cnf files containing a plaintext password
    out=$(sh_wrap 'for f in /root/.my.cnf /home/*/.my.cnf; do [ -f "$f" ] || continue; if grep -qE "^[[:space:]]*password[[:space:]]*=" "$f" 2>/dev/null; then echo "$f"; fi; done')
    save_raw '2.4_mycnf_passwords' "$out"
    if [ -z "$out" ]; then
        check_result '2.4' 'Process' '.my.cnf files have no plaintext password' 'Medium' 'Pass' \
            'No .my.cnf files with a stored password' '-'
    else
        check_result '2.4' 'Process' '.my.cnf files have no plaintext password' 'Medium' 'Warn' \
            "Plaintext password in: $out" \
            'Migrate to mysql_config_editor login paths (mysql --login-path=<name>).'
    fi
}

# =============================================================================
# 3. ENCRYPTION AT REST (client-visible via SHOW VARIABLES)
# =============================================================================
run_section_encryption() {
    section_hdr '3. Encryption at Rest'

    local v out

    # 3.1 innodb_redo_log_encrypt
    v=$(svar 'innodb_redo_log_encrypt')
    save_raw '3.1_redo_log_encrypt' "$v"
    if [ "$v" = "ON" ] || [ "$v" = "1" ]; then
        check_result '3.1' 'Encryption' 'InnoDB redo log encryption' 'High' 'Pass' \
            "innodb_redo_log_encrypt=$v" '-'
    else
        check_result '3.1' 'Encryption' 'InnoDB redo log encryption' 'High' 'Warn' \
            "innodb_redo_log_encrypt=$v (redo log stored in cleartext)" \
            'Install a keyring component and set innodb_redo_log_encrypt=ON.'
    fi

    # 3.2 innodb_undo_log_encrypt
    v=$(svar 'innodb_undo_log_encrypt')
    save_raw '3.2_undo_log_encrypt' "$v"
    if [ "$v" = "ON" ] || [ "$v" = "1" ]; then
        check_result '3.2' 'Encryption' 'InnoDB undo log encryption' 'High' 'Pass' \
            "innodb_undo_log_encrypt=$v" '-'
    else
        check_result '3.2' 'Encryption' 'InnoDB undo log encryption' 'High' 'Warn' \
            "innodb_undo_log_encrypt=$v (undo log stored in cleartext)" \
            'Set innodb_undo_log_encrypt=ON after enabling a keyring component.'
    fi

    # 3.3 binlog_encryption (only relevant when binlog is on)
    local bl_on
    bl_on=$(svar 'log_bin')
    v=$(svar 'binlog_encryption')
    save_raw '3.3_binlog_encryption' "log_bin=$bl_on binlog_encryption=$v"
    if [ "$bl_on" = "OFF" ] || [ "$bl_on" = "0" ]; then
        check_result '3.3' 'Encryption' 'Binary log encryption' 'Medium' 'Info' \
            'Binary logging is OFF - binlog_encryption not applicable' '-'
    elif [ "$v" = "ON" ] || [ "$v" = "1" ]; then
        check_result '3.3' 'Encryption' 'Binary log encryption' 'High' 'Pass' \
            "binlog_encryption=$v" '-'
    else
        check_result '3.3' 'Encryption' 'Binary log encryption' 'High' 'Fail' \
            "binlog_encryption=$v (binlog contains DDL/DML in cleartext)" \
            'Set binlog_encryption=ON after installing a keyring component.'
    fi

    # 3.4 keyring component / plugin loaded
    out=$(sfirst "SELECT COMPONENT_URN FROM mysql.component WHERE COMPONENT_URN LIKE '%keyring%' LIMIT 1;" 2>/dev/null)
    if [ -z "$out" ]; then
        out=$(sfirst "SELECT PLUGIN_NAME FROM information_schema.plugins WHERE PLUGIN_NAME LIKE 'keyring%' AND PLUGIN_STATUS='ACTIVE' LIMIT 1;")
    fi
    save_raw '3.4_keyring' "$out"
    if [ -n "$out" ]; then
        check_result '3.4' 'Encryption' 'Keyring loaded (for TDE)' 'High' 'Pass' \
            "keyring active: $out" '-'
    else
        check_result '3.4' 'Encryption' 'Keyring loaded (for TDE)' 'High' 'Warn' \
            'No keyring component/plugin active' \
            'Install component_keyring_file (or a KMS-backed keyring) so TDE can encrypt at rest.'
    fi

    # 3.5 default_table_encryption
    v=$(svar 'default_table_encryption')
    save_raw '3.5_default_table_encryption' "$v"
    if [ "$v" = "ON" ] || [ "$v" = "1" ]; then
        check_result '3.5' 'Encryption' 'New tables encrypted by default' 'Medium' 'Pass' \
            "default_table_encryption=$v" '-'
    else
        check_result '3.5' 'Encryption' 'New tables encrypted by default' 'Medium' 'Warn' \
            "default_table_encryption=$v" \
            'Set default_table_encryption=ON so new tables in default schemas inherit TDE.'
    fi
}

# =============================================================================
# 4. BACKUP READINESS
# =============================================================================
run_section_backup() {
    section_hdr '4. Backup Readiness'

    # 4.1 binary log retention (binlog_expire_logs_seconds)
    local v
    v=$(svar 'binlog_expire_logs_seconds')
    save_raw '10.1_binlog_expire' "$v"
    if [ "${v:-0}" -gt 0 ] 2>/dev/null; then
        check_result '10.1' 'Backup' 'Binary log retention configured' 'Medium' 'Pass' \
            "binlog_expire_logs_seconds=$v ($((v/86400)) days)" '-'
    else
        check_result '10.1' 'Backup' 'Binary log retention configured' 'Medium' 'Warn' \
            "binlog_expire_logs_seconds=$v (retained indefinitely)" \
            'Set binlog_expire_logs_seconds to a policy-appropriate value (e.g. 604800 = 7 days).'
    fi

    # 4.2 backup evidence: look for recent .sql or .sql.gz dumps
    local out
    out=$(sh_wrap 'find /var/backups /backup /opt/backup /home/*/backup -maxdepth 3 -type f \( -name "*.sql*" -o -name "*.tar.gz" \) -mtime -7 2>/dev/null | head -3')
    save_raw '10.2_backup_files' "$out"
    if [ -n "$out" ]; then
        check_result '10.2' 'Backup' 'Recent backup file present' 'Medium' 'Pass' \
            "Backup file(s) newer than 7 days: $(echo $out | tr '\n' ' ' | head -c 100)" '-'
    else
        check_result '10.2' 'Backup' 'Recent backup file present' 'Medium' 'Warn' \
            'No backup files in typical locations (last 7 days)' \
            'Schedule a nightly mysqldump / mysqlbackup / xtrabackup and verify the archive is written to a durable location.'
    fi
}

# =============================================================================
# Driver
# =============================================================================
run_all_os_checks() {
    run_section_os_files
    run_section_os_process
    run_section_encryption
    run_section_backup
}
