#!/usr/bin/env bash
# =============================================================================
# lib/output.sh
# Formatting + report writer. Emits colour to stdout, and appends structured
# rows to $REPORT_TXT / $REPORT_CSV / $RAW_DIR.
# =============================================================================

# Colours (terminal). Falls back to no-op strings when stdout is not a TTY.
if [ -t 1 ]; then
    C_PASS='\033[1;32m'; C_FAIL='\033[1;31m'; C_WARN='\033[1;33m'
    C_INFO='\033[1;36m'; C_HDR='\033[1;35m';  C_MUTE='\033[0;90m'; C_NC='\033[0m'
else
    C_PASS=; C_FAIL=; C_WARN=; C_INFO=; C_HDR=; C_MUTE=; C_NC=
fi

# Counters (populated as check_result is called)
declare -i CNT_PASS=0
declare -i CNT_FAIL=0
declare -i CNT_WARN=0
declare -i CNT_INFO=0
declare -i CNT_TOTAL=0

init_report() {
    : > "$REPORT_TXT"
    echo "id,section,item,severity,status,evidence,recommendation" > "$REPORT_CSV"
    mkdir -p "$RAW_DIR"
    {
        echo "==============================================================="
        echo " MySQL Security Audit"
        echo " Client   : ${CLIENT_NAME:-N/A}"
        echo " Target   : ${DB_LABEL:-N/A}  (${MYSQL_HOST}:${MYSQL_PORT})"
        echo " Run at   : $(date -u '+%Y-%m-%d %H:%M:%S UTC')"
        echo "==============================================================="
        echo
    } | tee -a "$REPORT_TXT"
}

section_hdr() {
    local title="$1"
    printf '\n%b--- %s ---%b\n' "$C_HDR" "$title" "$C_NC" | tee -a "$REPORT_TXT"
}

# check_result <id> <section> <item> <severity> <status> <evidence> <recommendation>
# status  : Pass | Fail | Warn | Info
# severity: Low | Medium | High | Critical | Info
check_result() {
    local id="$1" sec="$2" item="$3" sev="$4" status="$5" ev="$6" rec="$7"
    local clr icon
    case "$status" in
        Pass)  clr="$C_PASS"; icon='[+]'; CNT_PASS=$((CNT_PASS+1));;
        Fail)  clr="$C_FAIL"; icon='[X]'; CNT_FAIL=$((CNT_FAIL+1));;
        Warn)  clr="$C_WARN"; icon='[!]'; CNT_WARN=$((CNT_WARN+1));;
        Info)  clr="$C_INFO"; icon='[i]'; CNT_INFO=$((CNT_INFO+1));;
        *)     clr="$C_MUTE"; icon='[?]';;
    esac
    CNT_TOTAL=$((CNT_TOTAL+1))
    # tty output
    printf '  %b%s%b %-6s %-45s %b%s%b\n' \
        "$clr" "$icon" "$C_NC" "[$sev]" "$item" "$clr" "$status" "$C_NC"
    if [ -n "$ev" ]; then
        printf '      %bevidence:%b %s\n' "$C_MUTE" "$C_NC" "$ev"
    fi
    if [ "$status" = "Fail" ] || [ "$status" = "Warn" ]; then
        printf '      %brecommend:%b %s\n' "$C_MUTE" "$C_NC" "$rec"
    fi
    # text report
    {
        printf '  %s %-6s %-45s %s\n' "$icon" "[$sev]" "$item" "$status"
        [ -n "$ev" ]  && printf '      evidence : %s\n' "$ev"
        if [ "$status" = "Fail" ] || [ "$status" = "Warn" ]; then
            printf '      recommend: %s\n' "$rec"
        fi
    } >> "$REPORT_TXT"
    # csv report
    csv_row "$id" "$sec" "$item" "$sev" "$status" "$ev" "$rec" >> "$REPORT_CSV"
}

# csv-safe cell: quote and double-up embedded quotes
csv_cell() {
    printf '"%s"' "$(printf '%s' "$1" | sed 's/"/""/g' | tr '\n' ' ')"
}

csv_row() {
    local first=1
    for a in "$@"; do
        [ "$first" -eq 1 ] && first=0 || printf ','
        csv_cell "$a"
    done
    printf '\n'
}

finalize_report() {
    {
        echo
        echo "==============================================================="
        echo " Summary"
        printf '   Total checks : %d\n' "$CNT_TOTAL"
        printf '   Pass         : %d\n' "$CNT_PASS"
        printf '   Fail         : %d\n' "$CNT_FAIL"
        printf '   Warn         : %d\n' "$CNT_WARN"
        printf '   Info         : %d\n' "$CNT_INFO"
        echo "==============================================================="
    } | tee -a "$REPORT_TXT"
}

save_raw() {
    # $1 = check id, $2 = content
    local id="$1"; shift
    printf '%s\n' "$*" > "$RAW_DIR/${id}.txt"
}
