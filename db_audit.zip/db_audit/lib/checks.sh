#!/usr/bin/env bash
# =============================================================================
# lib/checks.sh
# All CIS MySQL 8.0 (Level-1) style checks that can be verified from the
# client side over a normal DB connection. Each function calls check_result
# with a deterministic id so the row lands consistently in the CSV.
#
# Convention:
#   svar <name>            -> value of a mysql system variable (empty if unset)
#   scount "<sql>"         -> integer count returned by a COUNT(*) query
#   sfirst "<sql>"         -> single scalar value (first row / first column)
# =============================================================================

svar() {
    local name="$1"
    mysql_q_nohdr "SHOW VARIABLES LIKE '$name';" \
        | awk -F'\t' '{print $2; exit}'
}

scount() {
    mysql_q_nohdr "$1" | head -1 | awk '{print $1+0}'
}

sfirst() {
    mysql_q_nohdr "$1" | head -1
}

# =============================================================================
# SECTION 4  -  GENERAL HARDENING
# =============================================================================
run_section_general() {
    section_hdr '4. General Hardening'

    # 4.1 local_infile = OFF
    local v
    v=$(svar 'local_infile')
    save_raw '4.1_local_infile' "$v"
    if [ "$v" = "OFF" ] || [ "$v" = "0" ]; then
        check_result '4.1' 'General' 'local_infile disabled' 'Medium' 'Pass' \
            "local_infile=$v" \
            '-'
    else
        check_result '4.1' 'General' 'local_infile disabled' 'Medium' 'Fail' \
            "local_infile=$v (allows LOAD DATA LOCAL from client)" \
            'Set local_infile=OFF in my.cnf and restart MySQL.'
    fi

    # 4.2 secure_file_priv restricted (not empty, not / )
    v=$(svar 'secure_file_priv')
    save_raw '4.2_secure_file_priv' "$v"
    if [ -z "$v" ]; then
        check_result '4.2' 'General' 'secure_file_priv restricted' 'High' 'Fail' \
            'secure_file_priv is empty - LOAD/SELECT INTO OUTFILE can touch any file readable by mysqld' \
            'Set secure_file_priv to a dedicated directory (e.g. /var/lib/mysql-files/) in my.cnf.'
    elif [ "$v" = "NULL" ]; then
        check_result '4.2' 'General' 'secure_file_priv restricted' 'High' 'Pass' \
            'secure_file_priv=NULL - file import/export disabled entirely' \
            '-'
    else
        check_result '4.2' 'General' 'secure_file_priv restricted' 'High' 'Pass' \
            "secure_file_priv=$v" '-'
    fi

    # 4.3 sql_mode contains STRICT_ALL_TABLES or STRICT_TRANS_TABLES
    v=$(svar 'sql_mode')
    save_raw '4.3_sql_mode' "$v"
    if echo "$v" | grep -qE 'STRICT_(ALL|TRANS)_TABLES'; then
        check_result '4.3' 'General' 'strict sql_mode enforced' 'Medium' 'Pass' \
            "sql_mode contains STRICT flag" '-'
    else
        check_result '4.3' 'General' 'strict sql_mode enforced' 'Medium' 'Fail' \
            "sql_mode=$v (missing STRICT_ALL_TABLES / STRICT_TRANS_TABLES)" \
            'Add STRICT_ALL_TABLES (or STRICT_TRANS_TABLES) to sql_mode in my.cnf.'
    fi

    # 4.4 have_symlink = DISABLED
    v=$(svar 'have_symlink')
    save_raw '4.4_have_symlink' "$v"
    if [ "$v" = "DISABLED" ]; then
        check_result '4.4' 'General' 'symbolic links disabled' 'Medium' 'Pass' \
            "have_symlink=$v" '-'
    else
        check_result '4.4' 'General' 'symbolic links disabled' 'Medium' 'Fail' \
            "have_symlink=$v (should be DISABLED)" \
            'Add skip-symbolic-links to [mysqld] section of my.cnf.'
    fi

    # 4.5 test_plugin (allow-suspicious-udfs) - proxied via have_dynamic_loading
    #     Instead check daemon_memcached plugin state (only load if needed).
    v=$(sfirst "SELECT PLUGIN_NAME FROM information_schema.plugins WHERE PLUGIN_NAME='daemon_memcached' AND PLUGIN_STATUS='ACTIVE';")
    save_raw '4.5_daemon_memcached' "$v"
    if [ -z "$v" ]; then
        check_result '4.5' 'General' 'daemon_memcached plugin disabled' 'Low' 'Pass' \
            'daemon_memcached is not active' '-'
    else
        check_result '4.5' 'General' 'daemon_memcached plugin disabled' 'Low' 'Warn' \
            'daemon_memcached plugin is active' \
            'Uninstall the plugin unless memcached protocol is required.'
    fi
}

# =============================================================================
# SECTION 5  -  USER PRIVILEGES
# =============================================================================
run_section_privileges() {
    section_hdr '5. User Privileges'

    # 5.1 FILE privilege only on admin users
    local sql count out
    sql="SELECT GROUP_CONCAT(User,'@',Host) FROM mysql.user WHERE File_priv='Y' AND User NOT IN ('mysql.sys','mysql.session','mysql.infoschema','root','mysql');"
    out=$(sfirst "$sql")
    save_raw '5.1_file_priv' "$out"
    if [ -z "$out" ] || [ "$out" = "NULL" ]; then
        check_result '5.1' 'Privileges' 'FILE privilege limited to admins' 'High' 'Pass' \
            'No non-admin account holds FILE' '-'
    else
        check_result '5.1' 'Privileges' 'FILE privilege limited to admins' 'High' 'Fail' \
            "FILE granted to: $out" \
            'REVOKE FILE ON *.* FROM the listed users. FILE lets an account read/write server files.'
    fi

    # 5.2 PROCESS privilege
    sql="SELECT GROUP_CONCAT(User,'@',Host) FROM mysql.user WHERE Process_priv='Y' AND User NOT IN ('mysql.sys','mysql.session','mysql.infoschema','root','mysql');"
    out=$(sfirst "$sql")
    save_raw '5.2_process_priv' "$out"
    if [ -z "$out" ] || [ "$out" = "NULL" ]; then
        check_result '5.2' 'Privileges' 'PROCESS limited to admins' 'Medium' 'Pass' \
            'No non-admin account holds PROCESS' '-'
    else
        check_result '5.2' 'Privileges' 'PROCESS limited to admins' 'Medium' 'Fail' \
            "PROCESS granted to: $out" \
            'REVOKE PROCESS ON *.* FROM the listed users. PROCESS exposes other users queries.'
    fi

    # 5.3 SUPER privilege (deprecated; check any account still has it)
    sql="SELECT GROUP_CONCAT(User,'@',Host) FROM mysql.user WHERE Super_priv='Y' AND User NOT IN ('mysql.sys','mysql.session','mysql.infoschema','root','mysql');"
    out=$(sfirst "$sql")
    save_raw '5.3_super_priv' "$out"
    if [ -z "$out" ] || [ "$out" = "NULL" ]; then
        check_result '5.3' 'Privileges' 'SUPER limited to admins' 'High' 'Pass' \
            'No non-admin account holds SUPER' '-'
    else
        check_result '5.3' 'Privileges' 'SUPER limited to admins' 'High' 'Fail' \
            "SUPER granted to: $out" \
            'Replace SUPER with the specific dynamic privileges required (SESSION_VARIABLES_ADMIN, etc.) and REVOKE SUPER.'
    fi

    # 5.4 SHUTDOWN privilege
    sql="SELECT GROUP_CONCAT(User,'@',Host) FROM mysql.user WHERE Shutdown_priv='Y' AND User NOT IN ('mysql.sys','mysql.session','mysql.infoschema','root','mysql');"
    out=$(sfirst "$sql")
    save_raw '5.4_shutdown_priv' "$out"
    if [ -z "$out" ] || [ "$out" = "NULL" ]; then
        check_result '5.4' 'Privileges' 'SHUTDOWN limited to admins' 'High' 'Pass' \
            'No non-admin account holds SHUTDOWN' '-'
    else
        check_result '5.4' 'Privileges' 'SHUTDOWN limited to admins' 'High' 'Fail' \
            "SHUTDOWN granted to: $out" \
            'REVOKE SHUTDOWN ON *.* FROM the listed users.'
    fi

    # 5.5 CREATE USER privilege
    sql="SELECT GROUP_CONCAT(User,'@',Host) FROM mysql.user WHERE Create_user_priv='Y' AND User NOT IN ('mysql.sys','mysql.session','mysql.infoschema','root','mysql');"
    out=$(sfirst "$sql")
    save_raw '5.5_create_user_priv' "$out"
    if [ -z "$out" ] || [ "$out" = "NULL" ]; then
        check_result '5.5' 'Privileges' 'CREATE USER limited to admins' 'High' 'Pass' \
            'No non-admin account can create users' '-'
    else
        check_result '5.5' 'Privileges' 'CREATE USER limited to admins' 'High' 'Fail' \
            "CREATE USER granted to: $out" \
            'REVOKE CREATE USER ON *.* FROM the listed users.'
    fi

    # 5.6 GRANT OPTION on global level
    sql="SELECT GROUP_CONCAT(User,'@',Host) FROM mysql.user WHERE Grant_priv='Y' AND User NOT IN ('mysql.sys','mysql.session','mysql.infoschema','root','mysql');"
    out=$(sfirst "$sql")
    save_raw '5.6_grant_option' "$out"
    if [ -z "$out" ] || [ "$out" = "NULL" ]; then
        check_result '5.6' 'Privileges' 'Global GRANT OPTION limited' 'High' 'Pass' \
            'No non-admin account holds global GRANT OPTION' '-'
    else
        check_result '5.6' 'Privileges' 'Global GRANT OPTION limited' 'High' 'Fail' \
            "GRANT OPTION granted to: $out" \
            'REVOKE GRANT OPTION ON *.* FROM the listed users. Constrain grant delegation to database scope only.'
    fi

    # 5.7 REPLICATION SLAVE (Repl_slave_priv) - warn if given to non-replication user
    sql="SELECT GROUP_CONCAT(User,'@',Host) FROM mysql.user WHERE Repl_slave_priv='Y' AND User NOT IN ('mysql.sys','mysql.session','mysql.infoschema','root','mysql');"
    out=$(sfirst "$sql")
    save_raw '5.7_repl_slave' "$out"
    if [ -z "$out" ] || [ "$out" = "NULL" ]; then
        check_result '5.7' 'Privileges' 'REPLICATION SLAVE limited' 'Medium' 'Pass' \
            'No non-admin account has REPLICATION SLAVE' '-'
    else
        check_result '5.7' 'Privileges' 'REPLICATION SLAVE limited' 'Medium' 'Info' \
            "REPLICATION SLAVE granted to: $out" \
            'Confirm this is a dedicated replication user with no other rights; otherwise REVOKE.'
    fi

    # 5.8 DML/DDL grants scoped to specific DB (spot-check *.* on user table)
    sql="SELECT GROUP_CONCAT(User,'@',Host) FROM mysql.user WHERE (Select_priv='Y' OR Insert_priv='Y' OR Update_priv='Y' OR Delete_priv='Y' OR Create_priv='Y' OR Drop_priv='Y') AND User NOT IN ('mysql.sys','mysql.session','mysql.infoschema','root','mysql');"
    out=$(sfirst "$sql")
    save_raw '5.8_star_dml_ddl' "$out"
    if [ -z "$out" ] || [ "$out" = "NULL" ]; then
        check_result '5.8' 'Privileges' 'Global DML/DDL limited to admins' 'High' 'Pass' \
            'No non-admin account holds *.* DML/DDL rights' '-'
    else
        check_result '5.8' 'Privileges' 'Global DML/DDL limited to admins' 'High' 'Fail' \
            "Global DML/DDL held by: $out" \
            'Restrict privileges to the specific database each user needs (GRANT ... ON db.* not *.*).'
    fi
}

# =============================================================================
# SECTION 6  -  LOGGING & AUDITING
# =============================================================================
run_section_logging() {
    section_hdr '6. Logging & Auditing'

    local v out
    v=$(svar 'log_error')
    save_raw '6.1_log_error' "$v"
    if [ -n "$v" ] && [ "$v" != "stderr" ]; then
        check_result '6.1' 'Logging' 'log_error path configured' 'Medium' 'Pass' \
            "log_error=$v" '-'
    else
        check_result '6.1' 'Logging' 'log_error path configured' 'Medium' 'Fail' \
            "log_error=$v (should be a persistent file)" \
            'Set log_error in my.cnf to a file path on a persistent volume.'
    fi

    v=$(svar 'log_error_verbosity')
    save_raw '6.2_log_error_verbosity' "$v"
    if [ "${v:-0}" -ge 2 ] 2>/dev/null; then
        check_result '6.2' 'Logging' 'log_error_verbosity >= 2' 'Low' 'Pass' \
            "log_error_verbosity=$v" '-'
    else
        check_result '6.2' 'Logging' 'log_error_verbosity >= 2' 'Low' 'Fail' \
            "log_error_verbosity=$v (drops warnings)" \
            'Set log_error_verbosity=2 (errors + warnings) or 3 (errors + warnings + notes).'
    fi

    # 6.3 general_log OFF
    v=$(svar 'general_log')
    save_raw '6.3_general_log' "$v"
    if [ "$v" = "OFF" ] || [ "$v" = "0" ]; then
        check_result '6.3' 'Logging' 'general_log disabled' 'Medium' 'Pass' \
            'general_log=OFF (queries not written to disk in cleartext)' '-'
    else
        check_result '6.3' 'Logging' 'general_log disabled' 'Medium' 'Warn' \
            "general_log=$v (query cleartext + credentials risk)" \
            'Set general_log=OFF unless actively troubleshooting.'
    fi

    # 6.4 log_raw OFF
    v=$(svar 'log_raw')
    save_raw '6.4_log_raw' "$v"
    if [ "$v" = "OFF" ] || [ "$v" = "0" ]; then
        check_result '6.4' 'Logging' 'log_raw disabled' 'Medium' 'Pass' \
            'log_raw=OFF (passwords redacted in logs)' '-'
    else
        check_result '6.4' 'Logging' 'log_raw disabled' 'Medium' 'Fail' \
            "log_raw=$v (passwords stored in cleartext in query log)" \
            'Set log_raw=OFF so passwords in queries are redacted.'
    fi

    # 6.5 audit_log plugin present
    out=$(sfirst "SELECT PLUGIN_NAME FROM information_schema.plugins WHERE PLUGIN_NAME LIKE 'audit_log' AND PLUGIN_STATUS='ACTIVE';")
    save_raw '6.5_audit_log_plugin' "$out"
    if [ -n "$out" ]; then
        check_result '6.5' 'Logging' 'audit_log plugin active' 'High' 'Pass' \
            "$out plugin active" '-'
    else
        check_result '6.5' 'Logging' 'audit_log plugin active' 'High' 'Warn' \
            'No audit_log / server_audit plugin active' \
            'Install and enable the audit_log (MySQL Enterprise) or server_audit (Percona/MariaDB) plugin.'
    fi
}

# =============================================================================
# SECTION 7  -  AUTHENTICATION
# =============================================================================
run_section_auth() {
    section_hdr '7. Authentication'

    local v out cnt

    # 7.1 Anonymous accounts
    cnt=$(scount "SELECT COUNT(*) FROM mysql.user WHERE User='';")
    save_raw '7.1_anonymous_users' "$cnt"
    if [ "$cnt" -eq 0 ]; then
        check_result '7.1' 'Authentication' 'No anonymous accounts' 'High' 'Pass' \
            '0 anonymous accounts' '-'
    else
        check_result '7.1' 'Authentication' 'No anonymous accounts' 'High' 'Fail' \
            "$cnt anonymous account(s) present" \
            'DROP USER '"''"'@localhost;  DROP USER '"''"'@'"'"'%'"'"'; (adjust hostnames).'
    fi

    # 7.2 Empty / null password
    out=$(sfirst "SELECT GROUP_CONCAT(User,'@',Host) FROM mysql.user WHERE (authentication_string IS NULL OR authentication_string='') AND plugin NOT IN ('auth_socket','mysql_no_login','caching_sha2_password_generated');")
    save_raw '7.2_empty_password' "$out"
    if [ -z "$out" ] || [ "$out" = "NULL" ]; then
        check_result '7.2' 'Authentication' 'All accounts have a password' 'Critical' 'Pass' \
            'No account has an empty password' '-'
    else
        check_result '7.2' 'Authentication' 'All accounts have a password' 'Critical' 'Fail' \
            "Empty password on: $out" \
            'ALTER USER '"'"'user'"'"'@'"'"'host'"'"' IDENTIFIED BY '"'"'<strong-password>'"'"'; for each account listed.'
    fi

    # 7.3 default_authentication_plugin uses strong hashing (8.0 default is
    #     caching_sha2_password; MySQL 8.4+ uses authentication_policy)
    v=$(svar 'default_authentication_plugin')
    if [ -z "$v" ]; then
        v=$(svar 'authentication_policy')
    fi
    save_raw '7.3_default_auth_plugin' "$v"
    if echo "$v" | grep -qE 'caching_sha2_password|sha256_password'; then
        check_result '7.3' 'Authentication' 'Strong default auth plugin' 'Medium' 'Pass' \
            "default auth = $v" '-'
    else
        check_result '7.3' 'Authentication' 'Strong default auth plugin' 'Medium' 'Warn' \
            "default auth = $v" \
            'Use caching_sha2_password (default in MySQL 8+) as the default authentication plugin.'
    fi

    # 7.4 default_password_lifetime > 0
    v=$(svar 'default_password_lifetime')
    save_raw '7.4_password_lifetime' "$v"
    if [ "${v:-0}" -gt 0 ] 2>/dev/null; then
        check_result '7.4' 'Authentication' 'Password expiration set' 'Medium' 'Pass' \
            "default_password_lifetime=$v days" '-'
    else
        check_result '7.4' 'Authentication' 'Password expiration set' 'Medium' 'Warn' \
            "default_password_lifetime=$v (no expiration)" \
            'Set default_password_lifetime to a policy-appropriate number of days (e.g. 90).'
    fi

    # 7.5 password_history / password_reuse_interval
    local hist reuse
    hist=$(svar 'password_history'); reuse=$(svar 'password_reuse_interval')
    save_raw '7.5_password_reuse' "history=$hist reuse=$reuse"
    if [ "${hist:-0}" -gt 0 ] 2>/dev/null || [ "${reuse:-0}" -gt 0 ] 2>/dev/null; then
        check_result '7.5' 'Authentication' 'Password reuse policy enforced' 'Low' 'Pass' \
            "password_history=$hist, password_reuse_interval=$reuse" '-'
    else
        check_result '7.5' 'Authentication' 'Password reuse policy enforced' 'Low' 'Warn' \
            'Neither password_history nor password_reuse_interval is set' \
            'Set password_history >= 5 and/or password_reuse_interval >= 365 in my.cnf.'
    fi

    # 7.6 validate_password plugin active
    out=$(sfirst "SELECT PLUGIN_NAME FROM information_schema.plugins WHERE PLUGIN_NAME LIKE 'validate_password%' AND PLUGIN_STATUS='ACTIVE';")
    save_raw '7.6_validate_password' "$out"
    if [ -n "$out" ]; then
        check_result '7.6' 'Authentication' 'validate_password enforced' 'Medium' 'Pass' \
            "$out active" '-'
    else
        check_result '7.6' 'Authentication' 'validate_password enforced' 'Medium' 'Warn' \
            'validate_password plugin not active' \
            'INSTALL COMPONENT '"'"'file://component_validate_password'"'"'; and set a policy (MEDIUM+).'
    fi

    # 7.7 root accounts restricted to localhost (network exposure)
    out=$(sfirst "SELECT GROUP_CONCAT(User,'@',Host) FROM mysql.user WHERE User='root' AND Host NOT IN ('localhost','127.0.0.1','::1');")
    save_raw '7.7_root_remote' "$out"
    if [ -z "$out" ] || [ "$out" = "NULL" ]; then
        check_result '7.7' 'Authentication' 'root restricted to localhost' 'High' 'Pass' \
            'No remote root account' '-'
    else
        check_result '7.7' 'Authentication' 'root restricted to localhost' 'High' 'Fail' \
            "Remote root: $out" \
            'DROP USER '"'"'root'"'"'@'"'"'<remote-host>'"'"'; and manage remote administration via a dedicated admin account + jump host.'
    fi

    # 7.8 test database removed
    out=$(sfirst "SELECT SCHEMA_NAME FROM information_schema.schemata WHERE SCHEMA_NAME='test';")
    save_raw '7.8_test_db' "$out"
    if [ -z "$out" ]; then
        check_result '7.8' 'Authentication' "'test' database removed" 'Low' 'Pass' \
            "test schema does not exist" '-'
    else
        check_result '7.8' 'Authentication' "'test' database removed" 'Low' 'Fail' \
            'test schema exists (default from mysql_install_db)' \
            'DROP DATABASE test; and remove its privileges from the mysql.db table.'
    fi
}

# =============================================================================
# SECTION 8  -  NETWORK / TLS
# =============================================================================
run_section_network() {
    section_hdr '8. Network / TLS'

    local v out cnt

    # 8.1 require_secure_transport = ON
    v=$(svar 'require_secure_transport')
    save_raw '8.1_require_secure_transport' "$v"
    if [ "$v" = "ON" ] || [ "$v" = "1" ]; then
        check_result '8.1' 'Network' 'require_secure_transport ON' 'High' 'Pass' \
            'require_secure_transport=ON' '-'
    else
        check_result '8.1' 'Network' 'require_secure_transport ON' 'High' 'Fail' \
            "require_secure_transport=$v (plaintext connections allowed)" \
            'Set require_secure_transport=ON in my.cnf so only TLS clients can connect.'
    fi

    # 8.2 tls_version excludes TLSv1 and TLSv1.1
    v=$(svar 'tls_version')
    save_raw '8.2_tls_version' "$v"
    if echo "$v" | grep -qE 'TLSv1(,|$)|TLSv1\.1'; then
        check_result '8.2' 'Network' 'Modern TLS only' 'High' 'Fail' \
            "tls_version=$v (includes deprecated TLS)" \
            'Set tls_version=TLSv1.2,TLSv1.3 in my.cnf.'
    else
        check_result '8.2' 'Network' 'Modern TLS only' 'High' 'Pass' \
            "tls_version=$v" '-'
    fi

    # 8.3 users forced to SSL: count of non-admin accounts without ssl_type
    cnt=$(scount "SELECT COUNT(*) FROM mysql.user WHERE ssl_type='' AND User NOT IN ('mysql.sys','mysql.session','mysql.infoschema');")
    save_raw '8.3_ssl_type_users' "$cnt"
    if [ "$cnt" -eq 0 ]; then
        check_result '8.3' 'Network' 'All accounts require SSL' 'Medium' 'Pass' \
            'Every user has an ssl_type constraint' '-'
    else
        check_result '8.3' 'Network' 'All accounts require SSL' 'Medium' 'Warn' \
            "$cnt account(s) with no SSL constraint" \
            'ALTER USER ... REQUIRE SSL; (or X509) on each application account.'
    fi

    # 8.4 bind-address not 0.0.0.0 unless explicitly required
    v=$(svar 'bind_address')
    save_raw '8.4_bind_address' "$v"
    if [ "$v" = "0.0.0.0" ] || [ "$v" = "*" ] || [ "$v" = "::" ]; then
        check_result '8.4' 'Network' 'bind_address scoped' 'Medium' 'Warn' \
            "bind_address=$v (accepts on all interfaces)" \
            'Restrict bind_address to the interface(s) that need access; combine with host firewall.'
    else
        check_result '8.4' 'Network' 'bind_address scoped' 'Medium' 'Pass' \
            "bind_address=$v" '-'
    fi
}

# =============================================================================
# SECTION 9  -  VERSION / PATCHING
# =============================================================================
run_section_version() {
    section_hdr '9. Version & Patching'

    local v major
    v=$(sfirst "SELECT VERSION();")
    save_raw '9.1_version' "$v"
    major=$(echo "$v" | awk -F'.' '{print $1"."$2}')
    if [ -z "$v" ]; then
        check_result '9.1' 'Version' 'MySQL version identified' 'Info' 'Info' \
            'Could not read VERSION()' '-'
    elif echo "$major" | grep -qE '^(3|4|5)\.'; then
        check_result '9.1' 'Version' 'Supported MySQL major version' 'High' 'Fail' \
            "MySQL version=$v (5.x and older are end-of-life)" \
            'Upgrade to MySQL 8.0 (LTS) or 8.4 (LTS).'
    else
        check_result '9.1' 'Version' 'Supported MySQL major version' 'Medium' 'Pass' \
            "MySQL version=$v" '-'
    fi
}

# =============================================================================
# TOP-LEVEL DRIVER
# =============================================================================
run_all_checks() {
    run_section_general
    run_section_privileges
    run_section_logging
    run_section_auth
    run_section_network
    run_section_version
}
