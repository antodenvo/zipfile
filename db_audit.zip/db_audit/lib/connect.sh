#!/usr/bin/env bash
# =============================================================================
# lib/connect.sh
# Opens an SSH tunnel (if configured), verifies the MySQL client is present,
# and exposes:
#   mysql_q "<SQL statement>"                       -> raw tab-separated output
#   mysql_q_nohdr "<SQL statement>"                 -> same, without header row
#   mysql_hdr_json "<SQL statement>"                -> JSON array of rows
#   close_tunnel                                    -> tear down the tunnel
# =============================================================================

TUNNEL_PID=""

# -----------------------------------------------------------------------------
# ssh_common_args / ssh_x / ssh_x_tunnel: pick up SSH_USER, SSH_PORT,
# SSH_KEY_FILE, SSH_PASSWORD from config.env so every ssh call in the toolkit
# honours them (no dependency on ~/.ssh/config).
# -----------------------------------------------------------------------------
ssh_common_args() {
    local a=()
    [ -n "${SSH_PORT:-}" ]     && a+=(-p "$SSH_PORT")
    [ -n "${SSH_KEY_FILE:-}" ] && a+=(-i "$SSH_KEY_FILE")
    a+=(-o StrictHostKeyChecking=accept-new -o LogLevel=ERROR
        -o UserKnownHostsFile="${HOME}/.ssh/known_hosts")
    printf '%s\n' "${a[@]}"
}

ssh_target() {
    if [ -n "${SSH_USER:-}" ]; then
        printf '%s@%s' "$SSH_USER" "$SSH_HOST"
    else
        printf '%s' "$SSH_HOST"
    fi
}

ssh_x() {
    local -a common
    mapfile -t common < <(ssh_common_args)
    local target
    target=$(ssh_target)
    if [ -n "${SSH_PASSWORD:-}" ]; then
        if ! command -v sshpass >/dev/null 2>&1; then
            echo "ERROR: SSH_PASSWORD is set but sshpass is not installed." >&2
            echo "        Install sshpass (apt: sshpass / choco: sshpass), or use SSH_KEY_FILE." >&2
            return 127
        fi
        sshpass -p "$SSH_PASSWORD" ssh "${common[@]}" "$target" "$@"
    else
        ssh "${common[@]}" "$target" "$@"
    fi
}

ssh_x_tunnel() {
    local fwd="$1"
    local -a common
    mapfile -t common < <(ssh_common_args)
    local target
    target=$(ssh_target)
    if [ -n "${SSH_PASSWORD:-}" ]; then
        if ! command -v sshpass >/dev/null 2>&1; then
            echo "ERROR: SSH_PASSWORD is set but sshpass is not installed." >&2
            return 127
        fi
        sshpass -p "$SSH_PASSWORD" \
            ssh -f -N -o ExitOnForwardFailure=yes "${common[@]}" \
                -L "$fwd" "$target"
    else
        ssh -f -N -o ExitOnForwardFailure=yes "${common[@]}" \
            -L "$fwd" "$target"
    fi
}

open_tunnel_if_needed() {
    # Skip tunneling when we're using docker exec or when no SSH host is set.
    if [ -z "${SSH_HOST:-}" ] || [ -n "${MYSQL_DOCKER_CONTAINER:-}" ]; then
        return 0
    fi
    if ! have_local_mysql; then
        # Nothing to tunnel to. connect will fall back to remote mysql client.
        return 0
    fi
    printf ' Opening SSH tunnel: %s:%s -> %s -> %s:%s\n' \
        "$MYSQL_HOST" "$MYSQL_PORT" "$SSH_HOST" "$SSH_TARGET_HOST" "$SSH_TARGET_PORT"
    ssh_x_tunnel "${MYSQL_HOST}:${MYSQL_PORT}:${SSH_TARGET_HOST}:${SSH_TARGET_PORT}"
    TUNNEL_PID=$(pgrep -f "ssh.*-L.*${MYSQL_HOST}:${MYSQL_PORT}:${SSH_TARGET_HOST}:${SSH_TARGET_PORT}.*${SSH_HOST}" | head -1 || true)
    sleep 1
}

close_tunnel() {
    if [ -n "$TUNNEL_PID" ]; then
        kill "$TUNNEL_PID" 2>/dev/null || true
        TUNNEL_PID=""
    fi
}

# -----------------------------------------------------------------------------
# mysql_wrap: prefer local mysql; if none locally, fall back to running mysql
# on the SSH_HOST (needs SSH_HOST set + mysql-client installed there).
# -----------------------------------------------------------------------------
have_local_mysql() { command -v mysql >/dev/null 2>&1; }

mysql_wrap() {
    # Priority:
    #   1. MYSQL_DOCKER_CONTAINER on SSH_HOST -> docker exec inside the container
    #   2. Local mysql client + SSH tunnel (or direct)
    #   3. mysql client on SSH_HOST connecting to SSH_TARGET_HOST:PORT
    # $1 = sql
    local sql="$1"
    if [ -n "${MYSQL_DOCKER_CONTAINER:-}" ] && [ -n "${SSH_HOST:-}" ]; then
        ssh_x \
            "docker exec -e MYSQL_PWD='$MYSQL_PASSWORD' '$MYSQL_DOCKER_CONTAINER' mysql -h 127.0.0.1 -u '$MYSQL_USER' --batch -e \"$sql\"" 2>&1
    elif have_local_mysql; then
        MYSQL_PWD="$MYSQL_PASSWORD" mysql \
            -h "$MYSQL_HOST" -P "$MYSQL_PORT" -u "$MYSQL_USER" \
            --batch -e "$sql" 2>&1
    elif [ -n "${SSH_HOST:-}" ]; then
        ssh_x \
            "MYSQL_PWD='$MYSQL_PASSWORD' mysql -h '$SSH_TARGET_HOST' -P '$SSH_TARGET_PORT' -u '$MYSQL_USER' --batch -e \"$sql\"" 2>&1
    else
        echo "ERROR: no local mysql client and SSH_HOST not set" >&2
        return 1
    fi
}

# Filter the noisy client warnings ("Using a password on the command line is
# insecure", etc.) that mysql prints to stderr and which we merge into stdout.
_strip_warnings() {
    grep -viE '^mysql: \[warning\]|^warning|using a password on the command'
}

# Detect a real query failure (permission denied, syntax error, connection
# reset). Returns 0 (true) if the payload looks like an error.
_looks_like_error() {
    grep -qiE '^ERROR [0-9]+|access denied|command denied|could not connect|lost connection|unknown column|table.*does'
}

mysql_q()       { mysql_wrap "$1" | _strip_warnings; }
mysql_q_nohdr() { mysql_wrap "$1" | _strip_warnings | tail -n +2; }

# -----------------------------------------------------------------------------
# sh_wrap: run an arbitrary shell command *on the DB host*.
# Used by lib/os_checks.sh for filesystem / process / permission checks.
# Priority (same order as mysql_wrap):
#   1. MYSQL_DOCKER_CONTAINER on SSH_HOST -> docker exec inside the container
#   2. SSH to SSH_HOST directly (assumes SSH_HOST *is* the DB host)
#   3. Run locally (assumes MySQL is on this box)
# -----------------------------------------------------------------------------
sh_wrap() {
    local cmd="$1"
    if [ -n "${MYSQL_DOCKER_CONTAINER:-}" ] && [ -n "${SSH_HOST:-}" ]; then
        ssh_x "docker exec '$MYSQL_DOCKER_CONTAINER' sh -c $(printf '%q' "$cmd")" 2>&1
    elif [ -n "${SSH_HOST:-}" ]; then
        ssh_x "sh -c $(printf '%q' "$cmd")" 2>&1
    else
        sh -c "$cmd" 2>&1
    fi
}

# Are OS-level checks even possible? true if we can reach the DB host shell.
os_access_available() {
    [ -n "${SSH_HOST:-}" ] || [ -z "${MYSQL_HOST:-}" ] || [ "$MYSQL_HOST" = "127.0.0.1" ] || [ "$MYSQL_HOST" = "localhost" ]
}

# One-shot connectivity check. Returns 0 on success, non-zero otherwise.
# Catches: SSH resolution failures, mysql client errors, socket refusal.
test_connection() {
    local out
    out=$(mysql_wrap "SELECT VERSION();" 2>&1 | _strip_warnings)
    # Any of these substrings means the connection didn't reach MySQL.
    if echo "$out" | grep -qiE 'error|access denied|refused|unknown|could not resolve|temporary failure|permission denied|host is down|timed out|no such host|nodename nor servname|ssh:'; then
        echo "$out"
        return 1
    fi
    # A valid version starts with a digit (e.g. 8.0.46).
    local last
    last=$(echo "$out" | tail -n1)
    if ! echo "$last" | grep -qE '^[0-9]+\.[0-9]+'; then
        echo "$out"
        return 1
    fi
    echo "$last"
    return 0
}
