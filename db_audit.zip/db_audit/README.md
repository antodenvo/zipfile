# MySQL DB Security Audit Toolkit

A CIS-aligned MySQL 8.0 configuration and hardening audit performed entirely
from a bash script (no MySQL server change, no agent install).

## What it checks

~40 items drawn from the CIS MySQL 8.0 Benchmark (Level 1) plus common
industry practices:

| Section | Coverage |
|---------|----------|
| General hardening  | `local_infile`, `secure_file_priv`, `skip-symbolic-links`, `sql_mode` |
| Auditing / logging | `log_error`, `log_error_verbosity`, `log_raw`, `general_log`, `audit_log` plugin |
| Authentication     | Anonymous accounts, empty passwords, password expiration policy, default auth plugin |
| User privileges    | `FILE`, `PROCESS`, `SUPER`, `SHUTDOWN`, `CREATE USER`, `GRANT OPTION`, `REPLICATION SLAVE`, DML/DDL scope |
| Network / TLS      | `require_secure_transport`, per-user `ssl_type`, `tls_version` |
| Database hygiene   | `test` database removed, `mysql` schema locked down, root remote-access |

Each check emits: **status** (Pass/Fail/Warn/Info), **evidence** (real value
observed), and a short **recommendation** so the client can act.

## Layout

```
db_audit/
├── README.md
├── config.env              # <- edit host / port / user / password here
├── audit_mysql.sh          # main driver
├── lib/
│   ├── connect.sh          # tunnel + client wrapper
│   ├── checks.sh           # CIS control functions
│   └── output.sh           # colour output + report writer
├── testbed/
│   ├── docker-run.sh       # spin MySQL Docker on the remote (idsserver)
│   └── seed.sql            # intentional-insecure seed data for testing
└── out/                    # generated reports
```

## Setup

Edit **`config.env`** and set the four connection knobs. Nothing else needs
touching.

```bash
MYSQL_HOST=127.0.0.1
MYSQL_PORT=3306
MYSQL_USER=root
MYSQL_PASSWORD=secret
```

If the database is reachable only via SSH jump, also set:

```bash
SSH_HOST=idsserver     # any entry in your ~/.ssh/config
SSH_TARGET_HOST=127.0.0.1   # host reachable FROM idsserver where MySQL listens
SSH_TARGET_PORT=3306
```

The audit will open a local port-forward from `MYSQL_HOST:MYSQL_PORT` to
`SSH_TARGET_HOST:SSH_TARGET_PORT` for the duration of the run and close it
afterwards.

## Run

```bash
bash audit_mysql.sh
```

Output lands in `out/mysql_audit_<timestamp>/`:

- `report.txt`  : human-readable, coloured pass/fail summary
- `report.csv`  : machine-readable table (id, section, item, status, severity, value, recommendation)
- `raw/`        : raw SQL / SHOW output for each check (audit trail)

## Test locally

To validate the script works before running against production:

```bash
bash testbed/docker-run.sh up      # deploy MySQL 8.0 container on idsserver
bash audit_mysql.sh                # run audit against it
bash testbed/docker-run.sh down    # tear down
```

`testbed/docker-run.sh up` also loads `testbed/seed.sql`, which intentionally
creates insecure users / grants / DBs so several checks flip to Fail. That way
you can see the tool detects real issues, not just Pass.

## Requirements

- OpenSSH (built-in on Windows 10+, Git Bash on Windows works)
- `mysql` client (installed automatically inside the SSH tunnel when the local
  box has no client)
- bash 4+
